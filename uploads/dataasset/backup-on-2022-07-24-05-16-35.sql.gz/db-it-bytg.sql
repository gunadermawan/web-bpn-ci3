#
# TABLE STRUCTURE FOR: tb_asset
#

DROP TABLE IF EXISTS `tb_asset`;

CREATE TABLE `tb_asset` (
  `id_asset` int(11) NOT NULL AUTO_INCREMENT,
  `nama_asset` varchar(50) NOT NULL,
  `model_asset` varchar(50) NOT NULL,
  `merk_asset` varchar(50) NOT NULL,
  `serial_asset` varchar(200) NOT NULL,
  `inventaris_asset` varchar(200) NOT NULL,
  `keterangan_asset` varchar(50) NOT NULL,
  `jml_asset` int(11) NOT NULL,
  `date_asset` int(20) NOT NULL,
  `kategori_asset` varchar(50) NOT NULL,
  `gambar_asset` varchar(100) NOT NULL,
  PRIMARY KEY (`id_asset`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tb_asset` (`id_asset`, `nama_asset`, `model_asset`, `merk_asset`, `serial_asset`, `inventaris_asset`, `keterangan_asset`, `jml_asset`, `date_asset`, `kategori_asset`, `gambar_asset`) VALUES (1, 'GUNA DERMAWAN', 'GD-1204', 'ggg', '12345678910', '-', 'BAIK - INBOX', 1, 1658586960, 'LEMARI 2.C (POWER SUPPLY)', 'f11df3894dcf2e1891c43b804b89ee3a.png');


#
# TABLE STRUCTURE FOR: user
#

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `image` varchar(128) NOT NULL,
  `password` varchar(256) NOT NULL,
  `role_id` varchar(10) NOT NULL,
  `is_active` varchar(10) NOT NULL,
  `date_created` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `user` (`id`, `name`, `email`, `image`, `password`, `role_id`, `is_active`, `date_created`) VALUES (1, 'gunadermawan', 'gunadermawan.official@gmail.com', 'default.png', '$2y$10$8fdBXsn5Yx.0v/LoTy/23efr6D4b5hW/WdkD.FRFxkb3EQ0lAJrzi', '2', '1', 1657974849);
INSERT INTO `user` (`id`, `name`, `email`, `image`, `password`, `role_id`, `is_active`, `date_created`) VALUES (2, 'ilham', 'ilham@email.com', 'default.png', '$2y$10$sY3w2Vpa8MG8bC6c8kmnLeqe4JaoVJ/b5OvrLx9JjQ/QFupTSx882', '1', '1', 1658057843);


#
# TABLE STRUCTURE FOR: user_access_menu
#

DROP TABLE IF EXISTS `user_access_menu`;

CREATE TABLE `user_access_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

INSERT INTO `user_access_menu` (`id`, `role_id`, `menu_id`) VALUES (1, 1, 1);
INSERT INTO `user_access_menu` (`id`, `role_id`, `menu_id`) VALUES (2, 1, 2);
INSERT INTO `user_access_menu` (`id`, `role_id`, `menu_id`) VALUES (3, 2, 2);


#
# TABLE STRUCTURE FOR: user_menu
#

DROP TABLE IF EXISTS `user_menu`;

CREATE TABLE `user_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menu` varchar(128) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `user_menu` (`id`, `menu`) VALUES (1, 'Admin');
INSERT INTO `user_menu` (`id`, `menu`) VALUES (2, 'User');


#
# TABLE STRUCTURE FOR: user_role
#

DROP TABLE IF EXISTS `user_role`;

CREATE TABLE `user_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role` varchar(128) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `user_role` (`id`, `role`) VALUES (1, 'administrator ');
INSERT INTO `user_role` (`id`, `role`) VALUES (2, 'member');


#
# TABLE STRUCTURE FOR: user_sub_menu
#

DROP TABLE IF EXISTS `user_sub_menu`;

CREATE TABLE `user_sub_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menu_id` int(11) NOT NULL,
  `title` varchar(128) NOT NULL,
  `url` varchar(128) NOT NULL,
  `icon` varchar(128) NOT NULL,
  `is_active` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

INSERT INTO `user_sub_menu` (`id`, `menu_id`, `title`, `url`, `icon`, `is_active`) VALUES (1, 1, 'Beranda', 'admin', 'fas fa-fw fa-house-user', 1);
INSERT INTO `user_sub_menu` (`id`, `menu_id`, `title`, `url`, `icon`, `is_active`) VALUES (2, 2, 'Profil', 'user', 'fas fa-fw fa-user', 1);
INSERT INTO `user_sub_menu` (`id`, `menu_id`, `title`, `url`, `icon`, `is_active`) VALUES (3, 2, 'Sunting Profil', 'user/edit', 'fas fa-fw fa-user-edit', 1);
INSERT INTO `user_sub_menu` (`id`, `menu_id`, `title`, `url`, `icon`, `is_active`) VALUES (4, 1, 'Tambah Pengguna', 'admin/user', 'fas fa-fw fa-user-plus', 1);
INSERT INTO `user_sub_menu` (`id`, `menu_id`, `title`, `url`, `icon`, `is_active`) VALUES (5, 2, 'Data Asset', 'user/dataasset', 'fas fa-database', 1);
INSERT INTO `user_sub_menu` (`id`, `menu_id`, `title`, `url`, `icon`, `is_active`) VALUES (6, 1, 'Backup Database', 'admin/backup', 'fas fa-cloud-download-alt', 1);


